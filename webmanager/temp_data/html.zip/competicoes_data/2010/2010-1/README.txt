AUGUSTA

- Primeira seletiva interna do DCC/UDESC - 22mai2010


IMPORTANTE

- A questão D permite múltiplas respostas e deve ser corrigida manualmente pelos juízes

- A questão A do aquecimento apresenta um erro na primeira linha da entrada. Em vez de 3, leia-se 2 casos de teste.


CRÉDITOS

- As questões A, C e F foram elaboradas no DCC/UDESC pelo Prof. Alexandre

- As questões B, D, E, H, sugeridas pelo Prof. Claudio, são de http://www.informatik.uni-ulm.de

- As questões G e I são de são de http://ipsc.ksp.sk

- A questão A do aquecimento foi elaborada no DCC/UDESC pelo Prof. Alexandre

- A questão B do aquecimento é de http://br.spoj.pl

- A questão C, sugerida pelo Prof. Claudio, do aquecimento é de http://www.informatik.uni-ulm.de

- As questões D e E foram traduzidas pelo Prof. Rosso. As demais traduções são do Prof. Alexandre

