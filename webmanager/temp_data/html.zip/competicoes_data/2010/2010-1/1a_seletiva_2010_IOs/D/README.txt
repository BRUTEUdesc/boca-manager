Este problema admite múltiplas soluções e a correção deve ser manual pelos juízes.
